#!/bin/sh
cd worker
python setup.py test
