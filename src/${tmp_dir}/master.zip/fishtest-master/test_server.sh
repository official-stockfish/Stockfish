#!/bin/sh
cd fishtest
python setup.py test
